clc;
clear;
close all;

%% RUL Estimation and alpha Plot
load('true_axialStiffness.mat');
load('PrognosisLSSVR_StageA.mat');

failure_Stiffness = 0.85*true_axial_stiffness(1);
threshold = failure_Stiffness;
pd = predictInputData;
od = org_data_set;


figure(1)
set(gcf,'color','w');
set(0, 'DefaultAxesFontName', 'Times New Roman');

subplot(4,2,1)
plot(od(1:10,1),od(1:10,2),'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(pd{4}(:,1),pd{4}(:,2),'--k','LineWidth',2);
plot(pd{5}(:,1),pd{5}(:,2),'--g','LineWidth',2);
plot(pd{6}(:,1),pd{6}(:,2),'--','color',[0.9290 0.6940 0.1250],'LineWidth',2);
plot(pd{7}(:,1),pd{7}(:,2),'--m','LineWidth',2);
plot(pd{8}(:,1),pd{8}(:,2),'--c','LineWidth',2);
plot(pd{9}(:,1),pd{9}(:,2),'--b','LineWidth',2);
plot(pd{10}(:,1),pd{10}(:,2),'--r','LineWidth',2);
pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
xlabel('Number of Cycles');
ylabel('CPST');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel
legend('Observations','Prediction at 2180 cycles','Prediction at 2627 cycles','Prediction at 3074 cycles',...
    'Prediction at 3521 cycles','Prediction at 3970 cycles','Prediction at 4419 cycles','Prediction at 4867 cycles');
legend boxoff;

subplot(4,2,2)
plot(od(1:10,1),od(1:10,3),'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(pd{4}(:,1),pd{4}(:,3),'--k','LineWidth',2);
plot(pd{5}(:,1),pd{5}(:,3),'--g','LineWidth',2);
plot(pd{6}(:,1),pd{6}(:,3),'--','color',[0.9290 0.6940 0.1250],'LineWidth',2);
plot(pd{7}(:,1),pd{7}(:,3),'--m','LineWidth',2);
plot(pd{8}(:,1),pd{8}(:,3),'--c','LineWidth',2);
plot(pd{9}(:,1),pd{9}(:,3),'--b','LineWidth',2);
plot(pd{10}(:,1),pd{10}(:,3),'--r','LineWidth',2);
pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
xlabel('Number of Cycles');
ylabel('AR Coefficient');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel

subplot(4,2,3)
plot(od(1:10,1),od(1:10,4),'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(pd{4}(:,1),pd{4}(:,4),'--k','LineWidth',2);
plot(pd{5}(:,1),pd{5}(:,4),'--g','LineWidth',2);
plot(pd{6}(:,1),pd{6}(:,4),'--','color',[0.9290 0.6940 0.1250],'LineWidth',2);
plot(pd{7}(:,1),pd{7}(:,4),'--m','LineWidth',2);
plot(pd{8}(:,1),pd{8}(:,4),'--c','LineWidth',2);
plot(pd{9}(:,1),pd{9}(:,4),'--b','LineWidth',2);
plot(pd{10}(:,1),pd{10}(:,4),'--r','LineWidth',2);
pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
xlabel('Number of Cycles');
ylabel('Mean');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel

subplot(4,2,4)
plot(od(1:10,1),od(1:10,5),'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(pd{4}(:,1),pd{4}(:,5),'--k','LineWidth',2);
plot(pd{5}(:,1),pd{5}(:,5),'--g','LineWidth',2);
plot(pd{6}(:,1),pd{6}(:,5),'--','color',[0.9290 0.6940 0.1250],'LineWidth',2);
plot(pd{7}(:,1),pd{7}(:,5),'--m','LineWidth',2);
plot(pd{8}(:,1),pd{8}(:,5),'--c','LineWidth',2);
plot(pd{9}(:,1),pd{9}(:,5),'--b','LineWidth',2);
plot(pd{10}(:,1),pd{10}(:,5),'--r','LineWidth',2);
pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
xlabel('Number of Cycles');
ylabel('RMS');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel

subplot(4,2,5)
plot(od(1:10,1),od(1:10,6),'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(pd{4}(:,1),pd{4}(:,6),'--k','LineWidth',2);
plot(pd{5}(:,1),pd{5}(:,6),'--g','LineWidth',2);
plot(pd{6}(:,1),pd{6}(:,6),'--','color',[0.9290 0.6940 0.1250],'LineWidth',2);
plot(pd{7}(:,1),pd{7}(:,6),'--m','LineWidth',2);
plot(pd{8}(:,1),pd{8}(:,6),'--c','LineWidth',2);
plot(pd{9}(:,1),pd{9}(:,6),'--b','LineWidth',2);
plot(pd{10}(:,1),pd{10}(:,6),'--r','LineWidth',2);
pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
xlabel('Number of Cycles');
ylabel('Shape Factor');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel

subplot(4,2,6)
plot(od(1:10,1),od(1:10,7),'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(pd{4}(:,1),pd{4}(:,7),'--k','LineWidth',2);
plot(pd{5}(:,1),pd{5}(:,7),'--g','LineWidth',2);
plot(pd{6}(:,1),pd{6}(:,7),'--','color',[0.9290 0.6940 0.1250],'LineWidth',2);
plot(pd{7}(:,1),pd{7}(:,7),'--m','LineWidth',2);
plot(pd{8}(:,1),pd{8}(:,7),'--c','LineWidth',2);
plot(pd{9}(:,1),pd{9}(:,7),'--b','LineWidth',2);
plot(pd{10}(:,1),pd{10}(:,7),'--r','LineWidth',2);
pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
xlabel('Number of Cycles');
ylabel('Impulse Factor');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel

subplot(4,2,7)
plot(od(1:10,1),od(1:10,8),'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(pd{4}(:,1),pd{4}(:,8),'--k','LineWidth',2);
plot(pd{5}(:,1),pd{5}(:,8),'--g','LineWidth',2);
plot(pd{6}(:,1),pd{6}(:,8),'--','color',[0.9290 0.6940 0.1250],'LineWidth',2);
plot(pd{7}(:,1),pd{7}(:,8),'--m','LineWidth',2);
plot(pd{8}(:,1),pd{8}(:,8),'--c','LineWidth',2);
plot(pd{9}(:,1),pd{9}(:,8),'--b','LineWidth',2);
plot(pd{10}(:,1),pd{10}(:,8),'--r','LineWidth',2);
pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
xlabel('Number of Cycles');
ylabel('Margin Factor');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel

