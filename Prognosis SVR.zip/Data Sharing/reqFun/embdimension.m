function [embdim , value] = embdimension(inputsignal,trial_window_length)

tau = 1 ;
% Assume embedding dimension
M = trial_window_length;   % window length = embedding dimension
X = inputsignal;
N = length(X); % length of generated time series
q = (M-1)*tau;

Y1 = zeros(N-q,M);
for m = 1:M    
  Y1(:,m) = X((1:N-q)+(m-1)*tau); %formation of hankel matrix
end
% performing SVD
S_mat = Y1'*Y1 /(N-M); 

[rho,Lambda] = eig(S_mat);
Lambda = diag(Lambda);               % extract the diagonal elements
[Lambda,ind]=sort(Lambda,'descend'); % sort eigenvalues
rho = rho(:,ind);                    % and eigenvectors

value = Lambda/max(Lambda); 
uLam =  0.1;
lLam = -0.1;
TF = find (value > lLam & value < uLam);
embdim = TF(1);



end