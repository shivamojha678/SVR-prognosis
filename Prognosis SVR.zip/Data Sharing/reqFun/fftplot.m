function [f fabs]=fftplot(Ts,Input)
% close all
% f=freq
% ft=FFT
% fr= Real part of FFT
% fi= Imag part of FFT
% fabs = Abs part of FFT
L=length(Input);
Fs=1/Ts; % sampling frequency
% NFFT = 2^nextpow2(L); % Next power of 2 from length of y
NFFT=L-1;
UT = fft(Input,NFFT)/L;
f = Fs/2*linspace(0,1,NFFT/2);
% % Plot single-sided amplitude spectrum.
ft=UT(1:floor(NFFT/2));

fabs=2*abs(ft);

% fr=real(ft); 
% fi=imag(ft);
% fphase=phase(ft);

