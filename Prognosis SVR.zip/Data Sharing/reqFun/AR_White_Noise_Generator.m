clc;
clear;
close all;

%% model order of AR wave

ar_model = 2;   %% can generate upto ar (3)
lab = strcat('AR(',num2str(ar_model),') Noise');

%%
totaltime = 120;

dt = 0.01;
time = 0:dt:totaltime;
ns = length(time);

w = randn(ns,1);
w = w-mean(w);
w = w/std(w)*0.01;


v = randn(ns,1);
v = v-mean(v);
v = v/std(v)*sqrt(0.64);


%%
    
if ar_model==1
    
     for n = 1:ns  

        if n == 1
            Y(n) = v(n,1);
        else 
            Y(n) = -0.7*Y(n-1) + v(n,1);
        end
          wave_signal(n) = Y(n);% + w(n,1);
     end
    
elseif ar_model ==2
    
     for n = 1:ns  

        if n == 1
            Y(n) = v(n,1);
        elseif n == 2
            Y(n) = -0.8*Y(n-1) + v(n,1);
        else
            Y(n) = -0.8* Y(n-1) - 0.5 * Y(n-2) + v(n,1);
        end
        wave_signal(n) = Y(n);% + w(n,1);
     end
     
elseif ar_model==3

    for n = 1:ns  

        if n == 1
            Y(n) = v(n,1);
        elseif n == 2
            Y(n) = -0.8*Y(n-1) + v(n,1);
        elseif n == 3
            Y(n) = -0.8* Y(n-1) -0.5 * Y(n-2) + v(n,1);
        else
            Y(n) = -0.8* Y(n-1) -0.5 * Y(n-2)  -0.3 * Y(n-3) + v(n,1);
        end
        wave_signal(n) = Y(n);% + w(n,1);

    end
else
    error('Make order between 1-3')
end

%% making amplitute to noise 200 mm 

maxim = max(abs(wave_signal));
wave_signal=wave_signal.*(200/maxim);

% %% loading white noise
% WN = load('2. ar_5min_2hz_smooth.txt');
% dt = 0.01;
% time = 0:dt:dt*(length(WN)-1);
% wave_signal = WN;

%% Plotting
figure
plot(time,wave_signal);
title(lab);
xlabel('Time(sec)');
ylabel('Amplitude');

%% FFT of Noise
figure
[max_x,abs_data,x] = fourier(wave_signal,dt);
plot(x,abs_data);
title(strcat('FFT plot of ',{' '},lab));

%% Filtering signal frequency between 0 to 5 Hz
fs = 1/dt;
fpass = [0.5 5];
wave_filtered = bandpass(wave_signal,fpass,fs);

figure
plot(time,wave_filtered);
title(strcat('Filtered wave generated from',{' '},lab));
xlabel('Time(sec)');
ylabel('Amplitude');

figure
[max_xf,abs_data_f,x_f] = fourier(wave_filtered,dt);
plot(x_f,abs_data_f);
title(strcat('FFT plot of Filtered Wave generated from ',{' '},lab));


%%
save('AR_WhiteNoise.mat','wave_signal','wave_filtered');