clc;
clear;
close all;

%load('SDOF_results.mat');
load('AR_WhiteNoise.mat');

%x1 = uddot1; x1 = x1';
x1 = wave_signal';

%% Algorithm Start
% define w and v
ns1 = length(x1);

w = randn(ns1,1);
w = (w-mean(w))/std(w);
w = w*0.001;% 0.01 is standard deviatoin of noise 'w'

v = randn(ns1,1);
v = (v-mean(v))/std(v);
v = v*0.8; % 0.8 is the standard deviation of v

%% initialising coefficients of tvar order 2
y = x1';
x(:,1) = [1,1];
P(:,:,1) = eye(2);
Qw = eye(2)*var(w);

%y = y-v';
for ii = 2:ns1
    if ii==1
        C = [0,0];
    elseif ii==2
        C = [y(1,ii-1),0];
    else
        C = [y(1,ii-1),y(1,ii-2)];
    end
         
    x1_0        = x(:,ii-1);
    P1_0        = P(:,:,ii-1) + Qw;
    y1_0(:,ii)  = C*x1_0;
    sig_y2      = C*P1_0*C' + var(v);
    K(:,ii)     = P1_0*C'/sig_y2;
    x(:,ii)     = x1_0 + K(:,ii)*(y(1,ii)-y1_0(:,ii));
    P(:,:,ii)   = (eye(2) - K(:,ii)*C)*P1_0;
    %P(:,:,ii)    = P1_0-K(:,ii)*sig_y2*K(:,ii)';
end

%%
ns = ns1;

for ii = 1:ceil(ns/50):ns
clf    
    subplot(4,1,1)
    plot(x1(1:ii),'LineWidth',1.2)
    hold on
    plot(y1_0(:,1:ii),'r')
    legend('Original wave without noise','TVAR predicted wave')
    title('Signal')
    xlim([0 ns])
    
    subplot(4,1,2)
    plot(x(1,1:ii))
    title('TVAR coefficient a1')
    xlim([0 ns])
    
    subplot(4,1,3)
    plot(x(2,1:ii))
    title('TVAR coefficient a2')
    xlim([0 ns])
        
    drawnow
end
% 
%%
% 
% x=x';
% coeff = -1*mean(x(400:end,:));
% temmp = horzcat(1,coeff);
% 
% tvar_xx = filter(1,temmp,x1);        % filters the data (removes noise)
% tvar_xx= tvar_xx./(std(tvar_xx)/std(x1));
% 
% figure
% plot(time,x1,'LineWidth',0.1); hold on; plot(time,tvar_xx,'r')
% legend('original wave','predicted wave using inbuilt TVAR function')
% ylabel('Dispacement(mm)'), xlabel('Time(seconds)')
% x=x';



%%
disp(['Mean of TVAR coefficient 1 is ',num2str(mean(x(1,:)))])
disp(['Mean of TVAR coefficient 2 is ',num2str(mean(x(2,:)))])


%% AR modelling on fitted white noise

inputwave= y;
ar_model = 2;

% AR(n) model
model = ar(inputwave,ar_model);          % inbuilt function for ar modelling

xx = filter(1,model.a,inputwave);        % filters the data (removes noise)
xx= xx./(std(xx)/std(inputwave));

% figure
% plot(time,inputwave,'LineWidth',2); hold on; plot(time,xx,'r')
% legend('original wave','predicted wave using AR')
% ylabel('Dispacement(mm)'), xlabel('Time(seconds)')

% print coefficients
ARC = model.a;
disp(['Coefficients by AR model are ',num2str(ARC(1)),' ,',num2str(ARC(2)),' ,',num2str(ARC(3))]);
%