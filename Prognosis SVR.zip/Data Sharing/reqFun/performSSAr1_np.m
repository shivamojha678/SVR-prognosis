function [output , B] = performSSAr1(input,dt,k,str_data)

x = input;
nps = length(x);
time = 0:dt:dt*(nps-1);
idx = 0.8;

time_lag = amis_timelag(x,500);
[embdim , value] = embdimension(x,2500);

tau = time_lag;
dim = embdim;

N=length(x);        % Total points on phase space 
T = N-(dim-1)*tau;  % Initialize the phase space
Y=zeros(T,dim);     % Phase space reconstruction with MOD

for i=1:T
   Y(i,:)=x(i+(0:dim-1)*tau)';
end
Y = Y/sqrt(T);


gavish_truncate(Y);

% SVD on Y
[u,s,v] = svd(Y,0);
s = diag(s);

% Calculate the Principal Components
pc = Y*v;

for i = 1:min(size(pc))
    r = xcorr(pc(:,i),x);
    rmax(i) = max(r);
end
normrmax = rmax'/max(rmax);
[B,I] = sort(normrmax,'descend');
k = B>=idx;
j=1;
for i = 1:length(I)
    if k(i)==1
        AA(j) = I(i);
    end
    j =j+1;
end
%%
% k = 1 or 2 or 3 or 4....etc or k = [m:n] where m and n are user choices
k = I(AA);  
% T is the length of the trajectory matrix and dim its dimension
[T,dim]=size(pc);

% N is the length of the time series
N = T+(dim-1)*tau;

% Reconstruct the k Principal Components
rpc = pc(:,k)*v(:,k)';

% Initialize xr
xr = zeros(N,1);
times = zeros(N,1);
% Reconstructed time series
for i=1:dim
   xr(1+(i-1)*tau:T+(i-1)*tau)=xr(1+(i-1)*tau:T+(i-1)*tau)+rpc(:,i);
   times(1+(i-1)*tau:T+(i-1)*tau)=times(1+(i-1)*tau:T+(i-1)*tau)+1;
end
xr_I1 = xr./times*sqrt(T);

% % %Plotting
% % [fy,fabsy] = fftplot(dt,x);
% % [f1,fabs1] = fftplot(dt,xr_I1);
% % % fs = 1/dt;
% % % [fabsy,fy] = pwelch(x,[],[],[],fs);
% % % [fabs1,f1] = pwelch(xr_I1,[],[],[],fs);
% % 
% % 
% % fabsy = fabsy./max(fabsy);
% % fabs1 = fabs1./max(fabs1);
% % 
% % figure,
% % set(0, 'DefaultAxesFontName', 'Times New Roman')
% % subplot(1,2,1);plot(fy,fabsy,'b','LineWidth',1.2);
% % xlabel('Frequency (Hz)'); ylabel('Normalized amplitude');%xlim([0 50]);
% % box on;
% % legend(str_data);
% % legend boxoff
% % pbaspect([1 1 1]) % squares the plot
% % xlim([0 50]); ylim([0 1.025]);
% % set(gca,'XTick', 0:10:50 ,'YTick',0:0.25:1); % Specifies axes intervals
% % set(findall(gcf, 'Type', 'axes'),'LineWidth',2,'FontSize',20); %Sets axes width and font size
% % set(findall(gcf, 'Type', 'Text'),'FontSize',20); % sets font size of xlabel and ylabel
% % 
% % % filtered signal
% % %figure,
% % subplot(1,2,2); plot(f1,fabs1,'r','Linewidth' ,1.2);
% % xlabel('Frequency (Hz)'); ylabel('Normalized amplitude');%xlim([0 50]);
% % box on;
% % legend(str_data);
% % legend boxoff;
% % pbaspect([1 1 1]); % squares the plot
% % xlim([0 50]); ylim([0 1.025]);
% % set(gca,'XTick', 0:10:50 ,'YTick',0:0.25:1); % Specifies axes intervals
% % set(findall(gcf, 'Type', 'axes'),'LineWidth',2,'FontSize',20); %Sets axes width and font size
% % set(findall(gcf, 'Type', 'Text'),'FontSize',20); % sets font size of xlabel and ylabel
% % 
% % 
% % 
% % % % figure,
% % % % subplot(2,2,1),plot(time,x,'linewidth',1);xlabel('Time(s)'); ylabel('Response'); title('Original'); 
% % % % subplot(2,2,2),plot(fy,fabsy,'linewidth',1);xlabel('\omega (Hz)'); ylabel(' X(\omega)'); xlim([0 50]);
% % % % subplot(2,2,3),plot(time,xr_I1(1:length(time)),'linewidth',1);xlabel('Time(s)'); ylabel('Response');title('Reconstructed signal');
% % % % subplot(2,2,4),plot(f1,fabs1,'linewidth',1);xlabel('\omega (Hz)'); ylabel(' X(\omega)'); xlim([0 50]);
% % % % set(findall(gcf, 'Type', 'axes'),'LineWidth',2,'FontSize',20); %Sets axes width and font size
% % % % set(findall(gca, 'Type', 'Line'),'LineWidth',2); % sets line thickness of plotted data
% % % % set(findall(gcf, 'Type', 'Text'),'FontSize',20); % sets font size of xlabel and ylabel
% % 
% % % figure,
% % % plot(fy,fabsy,'b',f1,fabs1,'r','linewidth' ,1);
% % % xlabel('\omega (Hz)');ylabel('X(\omega)');xlim([0 50]);
% % % title('Overlap of FFT of Original & Filtered Response');

output = [xr_I1];
end