function [CPST,MDPST,points_gene] = cpstmdpst(healthy,damaged,loop_inc,ref_dist,position_shift,max_points)
% Performing CPST and MDPST
% Healthy Data
X11 = [healthy(:,1) healthy(:,2) healthy(:,3)]; 
Y11 = X11/max(abs(X11(:,1)));
figure
plot3(Y11(:,1),Y11(:,2),Y11(:,3));
title('PST of Healthy State')
    % interpolating functions and increasing value to 3 times
    Y1_f=[];
    Y1_f(:,1)=interp(Y11(:,1),2);
    Y1_f(:,2)=interp(Y11(:,2),2);
    Y1_f(:,3)=interp(Y11(:,3),2);

% Damaged Data
X12 = [damaged(:,1) damaged(:,2) damaged(:,3)]; 
Y12 = X12/max(abs(X12(:,1)));
figure
plot3(Y12(:,1),Y12(:,2),Y12(:,3));
title('PST of Damaged State')
    % interpolating functions and increasing value to 3 times
    Y2_f=[];
    Y2_f(:,1)=interp(Y12(:,1),2);
    Y2_f(:,2)=interp(Y12(:,2),2);
    Y2_f(:,3)=interp(Y12(:,3),2);
 

iii=1;loop = 0; points_gene=0; counter0 = 0;
for i=1:loop_inc:max(size(Y2_f))-10
 
j=0; % Initialize j
% For every phase-space point
    for ii = 1:length(Y1_f)-11
        % Calculate the distance from the reference point
        dist = norm(Y2_f(i,:)-Y1_f(ii,:),2);
            if dist <= ref_dist % If it is less than r, count it
            j=j+1;
            lock(j)=ii;
            distance(j)=dist; 
            end
    
    end
    
     
if j==0
    lock = NaN;
    final_C_P_S_T_11(iii,1)=0;
    final_mahal_11(iii,1)=0;
    counter0 = counter0+1;
else
     [d_value ind] = sort(distance);
     lock_position = lock(1,ind(1:end));  
        if max(size(lock_position))<max_points
        no_it = max(size(lock_position));
        points_gene=points_gene+1;
        else
        no_it = max_points;
        end
    j=1;
    for jj=1:no_it
        % filling matrix with neibouring points at t
        Y1_f_neig(j,1:3)=Y1_f(lock_position(1,jj),1:3);
        % filling matrix with neibouring points at neib + r
        % shifting neibouring points with tau(r)
        Y1_f_neig_plus_r(j,1:3)=Y1_f(lock_position(1,jj)+position_shift,1:3);
        j=j+1;
    end
    % taking avg of neib
    Y1_f_neig_plus_r_hat=(sum(Y1_f_neig_plus_r,1))/(max(size(lock)));
    
    % taking point at t+tau
    Y2_f_r_plus_s = Y2_f(i+position_shift,:);

    final_C_P_S_T_11(iii,1)= norm(Y1_f_neig_plus_r_hat-Y2_f_r_plus_s,2)/(max(size(lock)));

    % fixing size of matrix for mahal calculation
        if max(size(Y1_f_neig_plus_r(:,1)))<=3
            final_mahal_11(iii,1)=0;
        else
           final_mahal_11(iii,1)= mahal(Y2_f_r_plus_s,Y1_f_neig_plus_r);
        end
end

iii = iii+1;
Y1_f_neig_plus_r = []; Y1_f_neig = [];
lock=[];lock_position=[];ind=[];
distance=[];d_value=[];
end
CPST=sum(final_C_P_S_T_11)/length(final_C_P_S_T_11);
MDPST=sum(final_mahal_11)/length(final_mahal_11);
end