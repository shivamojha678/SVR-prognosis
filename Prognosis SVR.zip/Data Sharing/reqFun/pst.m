function Y1 = pst(inputsignal,tau,embdim)

% embedding dimension
M = embdim;   % window length = embedding dimension
X = inputsignal;
N = length(X); % length of generated time series
q = (M-1)*tau;

Y1 = zeros(N-q,M);
for m = 1:M    
  Y1(:,m) = X((1:N-q)+(m-1)*tau); 
end


end