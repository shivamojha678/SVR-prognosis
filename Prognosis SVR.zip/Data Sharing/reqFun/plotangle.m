function angle1 = plotangle(signal1,signal2)

data = [signal1 signal2];
data1 = data./max(max(data));
[u1,s1,v1] = svd(data,0);
PC_Healthy = v1;

%% Plotting principal components
theta = atan(PC_Healthy(2,2)/PC_Healthy(1,2))+pi;
points = linspace(0, theta);% 100 points from 0 to theta
xCurve = 0.25.*cos(points);  % X coordinates of curve
yCurve = 0.25.*sin(points);
angle1 = theta*180/pi;
angle = num2str(theta*180/pi,4);
txt = strcat({' '},{' '},'\theta',{' '});
txt1 = strcat('\theta = ',{' '}, angle);
px = 0; py = 0.35;
% 
% figure
% set(0, 'DefaultAxesFontName', 'Times New Roman')
% scatter(data1(:,1),data1(:,2));
% grid on;hold on;
% plot([0,PC_Healthy(1,1)],[0,PC_Healthy(2,1)],'g');
% plot([0,PC_Healthy(1,2)],[0,PC_Healthy(2,2)],'r');
% hold on
% plot([0,-PC_Healthy(1,1)],[0,-PC_Healthy(2,1)],'g');
% plot([0,-PC_Healthy(1,2)],[0,-PC_Healthy(2,2)],'r');
% hold on
% xlabel('Reconstructed Signal 1')
% ylabel('Reconstructed Signal 2')
% plot([0,1],[0,0],'--k');
% hold on
% plot(xCurve, yCurve,'k','LineWidth',3);
% pbaspect([1 1 1]) 
% box on
% % legend boxoff
% axis([-1 1 -1 1 -1 1]); % sets axes limit
% text(px,py,txt,'HorizontalAlignment','left');
% text(0.9,0.9,txt1,'HorizontalAlignment','right')
% % set(gca,'XTick', -1:0.5:1,'YTick',-1:0.5:1,'ZTick',-1:0.5:1); % Specifies axes intervals
% set(findall(gcf, 'Type', 'axes'),'LineWidth',3,'FontSize',28); %Sets axes width and font size
% set(findall(gca, 'Type', 'Line'),'LineWidth',3); % sets line thickness of plotted data
% set(findall(gcf, 'Type', 'Text'),'FontSize',28); % sets font size of xlabel and ylabel

end
