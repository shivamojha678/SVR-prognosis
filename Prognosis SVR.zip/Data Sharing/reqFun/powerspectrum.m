%% plotting power spectrum
function [f, f0, power,power0] = powerspectrum(inputwave, dt)

fs = 1/dt;
n = length(inputwave);% number of samples

y = fft(inputwave);
          
f = (0:n-1)*(fs/n);     % frequency range
power = abs(y).^2/n;

y0 = fftshift(y);         % shift y values
f0 = (-n/2:n/2-1)*(fs/n); % 0-centered frequency range
power0 = abs(y0).^2/n;    % 0-centered power% power of the DFT

end