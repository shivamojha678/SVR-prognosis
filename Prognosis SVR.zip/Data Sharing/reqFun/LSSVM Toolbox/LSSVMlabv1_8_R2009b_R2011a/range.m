function y = range(x)
%RANGE  Sample range.

y = max(x) - min(x);

% Copyright (c) 2011,  KULeuven-ESAT-SCD, License & help @ http://www.esat.kuleuven.be/sista/lssvmlab