function [a] = performAR(input, cali)         

            x1 = input;
            ns1 = length(x1);

                       
            % initialising coefficients of ar order 3
            y = x1';
            a(:,3) = [0,0,0]';
            P(:,:,3) = eye(3);
            ln = 1;
                       
              for ii = 4:cali
                    
                    if ii==1
                        C = [0,0]';
                    elseif ii==2
                        C = [y(1,ii-1),0]';
                    elseif ii==3
                        C = [y(1,ii-1),y(1,ii-2)]';
                    else
                        C = [y(1,ii-1),y(1,ii-2),y(1,ii-3)]';
                    end

                    wn_0        = a(:,ii-1);
                    ybb_0(:,ii) = C'*wn_0;
                    en(:,ii)    = y(1,ii)-ybb_0(:,ii);
                    kn(:,ii)    = (1/ln)*P(:,:,ii-1)*C/(1 + (1/ln)*C'*P(:,:,ii-1)*C);
                    a(:,ii)     = wn_0 + kn(:,ii)*en(:,ii);
                    P(:,:,ii)   = (1/ln)*P(:,:,ii-1) - (1/ln)*kn(:,ii)*C'*P(:,:,ii-1);
              end
            
             a(:,3) = a(:,ii);
             P(:,:,3) = P(:,:,ii);
            
             for ii = 4:ns1
                    
                    if ii==1
                        C = [0,0]';
                    elseif ii==2
                        C = [y(1,ii-1),0]';
                    elseif ii==3
                        C = [y(1,ii-1),y(1,ii-2)]';
                    else
                        C = [y(1,ii-1),y(1,ii-2),y(1,ii-3)]';
                    end

                    wn_0        = a(:,ii-1);
                    ybb_0(:,ii) = C'*wn_0;
                    en(:,ii)    = y(1,ii)-ybb_0(:,ii);
                    kn(:,ii)    = (1/ln)*P(:,:,ii-1)*C/(1 + (1/ln)*C'*P(:,:,ii-1)*C);
                    a(:,ii)     = wn_0 + kn(:,ii)*en(:,ii);
                    P(:,:,ii)   = (1/ln)*P(:,:,ii-1) - (1/ln)*kn(:,ii)*C'*P(:,:,ii-1);
             end
             
end