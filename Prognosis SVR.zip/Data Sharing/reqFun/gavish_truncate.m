%% Gavish & Donoho
function [] = gavish_truncate(Y)

[U, S, V] = svd(Y,'econ');

beta = size(Y,2)/size(Y,1);
sigma = diag(S);
tau = optimal_SVHT_coef(beta,0)*median(sigma);
semilogy(sigma,'k-o','Linewidth',1.2)
hold on
semilogy(sigma(sigma>tau),'ro','Linewidth',1.2)

end