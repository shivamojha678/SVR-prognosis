X = H1;
[U, S, V] = svd(X,'econ');
%% Gavish & Donoho
beta = size(X,2)/size(X,1);
sigma = diag(S);
tau = optimal_SVHT_coef(beta,0)*median(sigma);
semilogy(sigma,'k-o','Linewidth',1.2)
hold on
semilogy(sigma(sigma>tau),'ro','Linewidth',1.2)


%% Elbow Method
singularValue = diag(S)./(sum(diag(S)));
figure(10);
subplot(1,2,1)
semilogy(diag(S),'-sb','LineWidth',1.2), grid on, hold on
semilogy(diag(S(1:62,1:62)),'-sr','LineWidth',1.5)
axis square;
xlabel('r')
ylabel('Singular value, \sigma_r')
xlim([-10 380])
subplot(1,2,2)
plot(cumsum(diag(S))/sum(diag(S)),'-sb','LineWidth',1.2), grid on,hold on,
plot(cumsum(diag(S(1:62,1:62)))/sum(diag(S)),'-sr','LineWidth',1.2),
axis square;
xlabel('r')
ylabel('Cumulative Energy')
xlim([-10 380]); ylim([0 1.1])
set(gcf,'Position',[100 100 550 240])
% plot(singularValue,'k','LineWidth',2);hold on;
% plot(singularValue(1:20),'ro');