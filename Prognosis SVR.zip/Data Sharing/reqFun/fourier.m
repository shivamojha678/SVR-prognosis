function [max_x,abs_data,x] = fourier( input_file,T )
%FOURIER Summary of this function goes here
%   Detailed explanation goes here

% prepared a colume of name 'A' which contains time domain signal

%paste your data in A column
 %enter your delta T
Fs=1/T;
L = max(size(input_file));    % Length of signal

t = (0:L-1)*T;                % Time vector       
NFFT = 2^nextpow2(L); % Next power of 2 from length of y
XX = fft(input_file(:),NFFT)/L;
x = Fs/2*linspace(0,1,NFFT/2+1);
x = x';
transformed_data = XX(1:NFFT/2+1);
transformed_data = transformed_data';

% Plot single-sided amplitude spectrum.

abs_data = abs(transformed_data);
[val,idx] = max(abs_data);

max_x = x(idx);
fprintf(" Time of occurance of maximum amplitude is %g \n\n ", max_x);

%subplot(2,1,1)
% figure
% plot(x(1:400),abs(transformed_data(1:400)),'Color','black')
% title('Single-Sided Amplitude Spectrum of Symmetrical mode')
% xlabel('Frequency (Hz)')
% ylabel('Amplitude')


end


