function time_lag = amis_timelag(mydata,laglimit)
lag = laglimit;
nBins = [15 15];
%figure
    [t,amis ,corrs] = ami(mydata,nBins,lag);
    TF = islocalmin(amis);
% figure
%     plot(t,amis./max(amis),t(TF),amis(TF)./max(amis),'rh');
%     set(gca,'XTick', 0:2:lag,'YTick',0:0.1:1); % Specifies axes intervals
%     title('AMIF of Damaged Signal','FontSize',24); 
%     legend('Signal');
%     legend boxoff;
%     pbaspect([1 1 1]);
%     grid on
%     xlabel('Lag');ylabel('Normalised AMIF')
%     set(findall(gcf, 'Type', 'axes'),'LineWidth',3,'FontSize',24); %Sets axes width and font size
%     set(findall(gca, 'Type', 'Line'),'LineWidth',3); % sets line thickness of plotted data
%     set(findall(gcf, 'Type', 'Text'),'FontSize',24); % sets font size of xlabel and ylabel
%     
index = find(TF==1);
firstLMtime = index(1);
time_lag = t(firstLMtime);
end