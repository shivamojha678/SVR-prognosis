function y = diracdelta(m)

y = 0;
if m == 0
    y = 1;
end