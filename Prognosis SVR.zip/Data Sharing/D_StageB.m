clc;
clear;
close all;

load('PrognosisLSSVR_StageA.mat');
load('true_axialStiffness.mat');

axial_stiffness = true_axial_stiffness;

for step = 4:10
    switch step
    case 4
        disp('Prediction at 2180 Cycles')
    case 5
        disp('Prediction at 2627 Cycles')
    case 6
        disp('Prediction at 3074 Cycles')
    case 7
        disp('Prediction at 3521 Cycles')
    case 8
        disp('Prediction at 3970 Cycles')
    case 9
        disp('Prediction at 4419 Cycles')
    case 10
        disp('Prediction at 4867 Cycles')
    otherwise
        disp('other value')
    end

    sX = org_data_set(1:step,:); sY1 = axial_stiffness(1:step); sY1old = sY1; sXold = sX;

    fp = 10;  %list of places to search for first parameter
    sp = 1;  %list of places to search for second parameter

    for i = 1:length(fp)
        for j = 1:length(sp)
            sfitness(i,j) = errfun_lin(fp(i),sp(j), sX, sY1);
        end
    end
    [sminval, sminidx] = min(sfitness);
    [sminvalall, scolidx] = min(sminval);
    srowidx = sminidx(scolidx);
    bestF = fp(srowidx);
    bestS = sp(scolidx);

    model = initlssvm(sX,sY1,'function',1,[bestF(1),bestS(1)],'lin_kernel');
    model = trainlssvm(model);
    sY1p = simlssvm(model,sX);

    % new training points
    sXtnew = predictInputData{step}(:,:);
    sYtnew = simlssvm(model,sXtnew);

    % update output set
    predict_stiffness = sYtnew;
    predictAxialStiffness{step} = sYtnew;

    figure(1)
    set(gcf,'color','w');
    set(0, 'DefaultAxesFontName', 'Times New Roman');
    plot(sXold(:,1),sY1old,'ok', 'LineWidth',1.2); hold on;
    plot([sX(:,1);sXtnew(:,1)],[sY1p;sYtnew],'--r','LineWidth',1.2);
    pbaspect([4 1.5 1]); grid on;
    xlabel('Number of Cycles');
    ylabel('Axial Stiffness');
    set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
    set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel
    pause(1);
end 

%save('PrognosisLSSVR_StageB.mat','predictAxialStiffness','predictInputData');

