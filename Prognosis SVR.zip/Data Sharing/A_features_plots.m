clc;
clear;
close all;

load('Feature_extracted_final.mat','final','CPST','arcoeff','T','trainingData','cycles');

figure
set(gcf,'color','w');
set(0, 'DefaultAxesFontName', 'Times New Roman');
subplot(4,3,1);plot(cycles(3:11)',CPST./10^-5,'color',[0.4660 0.6740 0.1880],'Linewidth',1.2); %title('(a) CPST');
pbaspect([4 1.5 1]); grid minor;
xlabel('Number of cycles'); ylabel('CPST (10^{-5})'); xlim([0,5000]); ylim([8.4,8.9]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,2);plot(cycles(2:11)',arcoeff(1,:),'color',[0.4660 0.6740 0.1880],'Linewidth',1.2);%title('(b) AR');
pbaspect([4 1.5 1]); grid minor;
xlabel('Number of cycles'); ylabel('AR coefficient'); xlim([0,5000]); ylim([1.25,1.55]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,3);plot(cycles(2:11)',final.mean,'color',[0.4660 0.6740 0.1880],'Linewidth',1.2); %title('(c) Mean');
pbaspect([4 1.5 1]); grid minor;
legend('Monotonous feature','Fontsize',18); legend box off;
xlabel('Number of cycles'); ylabel('Mean (\mu)'); xlim([0,5000]); ylim([100,125]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,4);plot(cycles(2:11)',final.Std,'r','Linewidth',1.2); %title('(d) Standard deviation');
pbaspect([4 1.5 1]); grid minor;
xlabel('Number of cycles'); 
ylabel({'Standard','deviation (\sigma)'}); xlim([0,5000]);  ylim([37,38]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,5);plot(cycles(2:11)',final.Skewness./10^-3,'r','Linewidth',1.2); %title('(e) Skewness');
pbaspect([4 1.5 1]); grid minor;
legend('Non-monotonous feature','Fontsize',18); legend box off;
xlabel('Number of cycles'); ylabel('Skewness (10^{-3})'); xlim([0,5000]); ylim([-15,0]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,6);plot(cycles(2:11)',final.Kurtosis,'r','Linewidth',1.2); %title('(f) Kurtosis');
pbaspect([4 1.5 1]); grid minor;
xlabel('Number of cycles'); ylabel('Kurtosis'); xlim([0,5000]); ylim([1.475,1.525]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,7);plot(cycles(2:11)',final.Peak2Peak,'r','Linewidth',1.2); %title('(g) Peak2Peak');
pbaspect([4 1.5 1]); grid minor;
xlabel('Number of cycles'); ylabel('Peak to peak'); xlim([0,5000]);  ylim([105,115]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,8);plot(cycles(2:11)',final.RMS,'color',[0.4660 0.6740 0.1880],'Linewidth',1.2); %title('(h) RMS');
pbaspect([4 1.5 1]); grid minor;
xlabel('Number of cycles'); ylabel('RMS'); xlim([0,5000]);  ylim([108,128]); 
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,9);plot(cycles(2:11)',final.CrestFactor,'r','Linewidth',1.2); %title('(i) Crest Factor');
pbaspect([4 1.5 1]); grid minor;
xlabel('Number of cycles'); ylabel('Crest factor'); xlim([0,5000]);  ylim([1.38,1.44]);
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,10);plot(cycles(2:11)',final.ShapeFactor,'color',[0.4660 0.6740 0.1880],'Linewidth',1.2); %title('(j) Shape Factor');
pbaspect([4 1.5 1]); grid minor; ylim([1.045 1.065]);
xlabel('Number of cycles'); ylabel('Shape factor'); xlim([0,5000]); ylim([1.045,1.065]);
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,11);plot(cycles(2:11)',final.ImpulseFactor,'color',[0.4660 0.6740 0.1880],'Linewidth',1.2); %title('(k) Impulse Factor');
pbaspect([4 1.5 1]); grid minor; ylim([1.45 1.55]);
xlabel('Number of cycles'); ylabel('Impulse factor'); xlim([0,5000]); ylim([1.45,1.55]);
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel

subplot(4,3,12);plot(cycles(2:11)',final.MarginFactor,'color',[0.4660 0.6740 0.1880],'Linewidth',1.2); %title('(l) Margin Factor');
pbaspect([4 1.5 1]); grid minor; ylim([0.012 0.015]);
xlabel('Number of cycles'); ylabel('Margin factor'); xlim([0,5000]); ylim([0.012,0.015]);
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel