clc;
clear;
close all;

%% RUL Estimation and alpha Plot
load('true_axialStiffness.mat');
load('PrognosisLSSVR_StageB.mat')

sXold = predictInputData{4}(1:10,:);
sY1old = predictAxialStiffness{4}(1:10,:);

failure_Stiffness = 0.85*true_axial_stiffness(1);
threshold = failure_Stiffness;

sX = predictInputData;
sY1p = predictAxialStiffness;

figure(1)
set(gcf,'color','w');
set(0, 'DefaultAxesFontName', 'Times New Roman');
plot(sXold(:,1),sY1old,'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
plot(sX{4}(:,1),sY1p{4}(:,:),'--r','LineWidth',1.8);
plot(sX{5}(:,1),sY1p{5}(:,:),'--g','LineWidth',1.8);
plot(sX{6}(:,1),sY1p{6}(:,:),'--b','LineWidth',1.8);
plot(sX{7}(:,1),sY1p{7}(:,:),'--m','LineWidth',1.8);
plot(sX{8}(:,1),sY1p{8}(:,:),'--','color',[0.9290 0.6940 0.1250],'LineWidth',1.8);
plot(sX{9}(:,1),sY1p{9}(:,:),'--c','LineWidth',1.8);
plot(sX{10}(:,1),sY1p{10}(:,:),'--k','LineWidth',1.8);
yline(threshold,'-.','LineWidth',1.2,'Label','Threshold','FontSize',16,'LabelHorizontalAlignment','left','FontAngle','italic');
pbaspect([1 1 1]); grid on; xlim([0,10000]); ylim([9,13])
xlabel('Number of cycles');
ylabel('Axial stiffness (kN/mm)');
set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel
legend('Observations','Prediction at 2180 cycles','Prediction at 2627 cycles','Prediction at 3074 cycles',...
    'Prediction at 3521 cycles','Prediction at 3970 cycles','Prediction at 4419 cycles','Prediction at 4867 cycles');
legend boxoff;

% calculating corresponding RUL cycles
idx_true = find(true_axial_stiffness<failure_Stiffness);
failure_cycles = true_cycles(idx_true(1));
trueRULHist = failure_cycles-true_cycles(1:10);

alpha = 0.2;
alphaPlus = trueRULHist + alpha*trueRULHist;
alphaMinus = trueRULHist - alpha*trueRULHist;
N = length(trueRULHist);
t = 1:N;

k = 1;
for step = 4:10
idx = find(predictAxialStiffness{step}(:,:)<failure_Stiffness);
EOL(k,1) = predictInputData{step}(idx(1),1);
CurrentCycle(k,1) = predictInputData{step}(step,1);
k = k+1;
end

estRULHist = EOL-CurrentCycle;
% Compute the bounds
ub = estRULHist + 0.05*estRULHist;
lb = estRULHist - 0.05*estRULHist;
CIRULHist = [lb,ub];


%% Alpha Plot
% Assuming failure occurs at 10000 cycles
alpha = 0.2;
detectTime = 4; % step
breakpoint = detectTime;
N = length(trueRULHist);
t = 1:N;
t21 = 1:length(estRULHist);
t2 = 4:1:10;
% Compute the alpha bounds
alphaPlus = trueRULHist + alpha*trueRULHist;
alphaMinus = trueRULHist - alpha*trueRULHist;

% ---------------- Alpha-Lambda Plot --------------------
figure
set(gcf,'color','w');
set(0, 'DefaultAxesFontName', 'Times New Roman');
hold on; box on;
plot(t, trueRULHist,'LineWidth',2);
fill([t fliplr(t)], [alphaPlus(t)' fliplr(alphaMinus(t)')], 'b', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
plot(t2, estRULHist, '--or', "LineWidth",2,'MarkerFaceColor','r');
%fill([t2 fliplr(t2)], [CIRULHist(:,1)' fliplr(CIRULHist(:,2)')], 'r', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
plot([breakpoint breakpoint], [1000 9000], 'k-.','LineWidth',2)
ylim([1000 9000]); xlim([1,10]);
pbaspect([1 1 1]); grid on;
xlabel('Time (x 1000 cycles)')
ylabel('RUL (Number of fatigue cycles)');
legend boxoff;
lgd = legend('True RUL','\alpha - \lambda accuracy zone', 'Predicted RUL','Breakpoint');
%lgd = legend('True RUL', ['\alpha = +\\-' num2str(alpha*100) '%'], 'Predicted RUL after algorithm triggers', ...
%        'Confidence interval of predicted RUL', 'Train-Test Breakpoint');
lgd.FontSize = 14;

set(findall(gcf, 'Type', 'axes'),'LineWidth',2,'FontSize',18); %Sets axes width and font size
set(findall(gcf, 'Type', 'Text'),'FontSize',18); % sets font size of xlabel and ylabel
