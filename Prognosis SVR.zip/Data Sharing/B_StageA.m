clc;
clear;
close all;

load('Feature_extracted_final.mat','final','T','trainingData');
load('true_axialStiffness.mat');
data = table2array(trainingData);
cycles = data(:,1);            
axial_stiffness = smooth(data(:,2),10);

CPST = data(:,3);  CPST(1) = CPST(2);  data(:,3) = CPST;

true_cycles = [true_cycles(1:end-1);[true_cycles(end):100:15000]'];
data_truncate = data(:,3:9); 
data_new = [cycles,data_truncate];
org_data_set = data_new;
org_axial_stiffness = axial_stiffness;
scycles = cycles;


for step = 4:10
    step
    sX = data_new(1:step,:); sY1 = axial_stiffness(1:step); sY1old = sY1; sXold = sX;

    for kk = 1:7
        
        if kk == 1
            mylabel = 'CPST';
        elseif kk == 2
            mylabel = 'AR Coefficient';
        elseif kk == 3
            mylabel = 'Mean';
        elseif kk == 4
            mylabel = 'RMS';
        elseif kk == 5
            mylabel = 'Shape factor';
        elseif kk == 6
            mylabel = 'Impulse Factor';
        elseif kk == 7
            mylabel = 'Margin Factor';
        end


        X = cycles(1:step); Y1 = data_truncate(1:step,kk); Y1old = Y1; Xold = X;

        firstparam = 1:1:10;  %list of places to search for first parameter
        secondparam = 1:1:1;  %list of places to search for second parameter

        for i = 1:length(firstparam)
            for j = 1:length(secondparam)
                fitness(i,j) = errfun(firstparam(i),secondparam(j), X, Y1);
            end
        end
        [minval, minidx] = min(fitness);
        [minvalall, colidx] = min(minval);
        rowidx = minidx(colidx);
        bestFirst = firstparam(rowidx);
        bestSecond = secondparam(colidx);

        model = initlssvm(X,Y1,'function',1,[bestFirst(1),bestSecond(1)],'poly_kernel');
        model = trainlssvm(model);
        Y1p = simlssvm(model,X);

        % new training points
        Xtnew = true_cycles;
        Ytnew = simlssvm(model,Xtnew);

        figure(1)
        set(gcf,'color','w');
        set(0, 'DefaultAxesFontName', 'Times New Roman');
        subplot(4,2,kk)
        plot(Xold,Y1old,'*k', 'LineWidth',1.2,'MarkerSize',10); hold on;
        plot(Xtnew,Ytnew,'--b','LineWidth',1.2);
        pbaspect([4 1.5 1]); grid on; xlim([0,10000]);
        xlabel('Number of Cycles');
        ylabel(mylabel);
        set(findall(gcf, 'Type', 'axes'),'LineWidth',1.2,'FontSize',16); %Sets axes width and font size
        set(findall(gcf, 'Type', 'Text'),'FontSize',16); % sets font size of xlabel and ylabel
        pause(0.1);

        data_feed(:,kk) = Ytnew;
    end
    
    % update input set
    predict_data = [true_cycles,data_feed];
    data_new = [org_data_set; [true_cycles(11:end,:), data_feed(11:end,:)]];
    predictInputData{step} = predict_data;

end 

%save('PrognosisLSSVVR_StageA.mat','predictInputData','org_data_set');

