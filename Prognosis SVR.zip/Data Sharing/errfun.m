function output = errfun(p1,p2, X, Y1)

model = initlssvm(X,Y1,'function',1,[p1,p2],'poly_kernel');
model = trainlssvm(model);
Y1p = simlssvm(model,X);

output = sum((Y1p-Y1).^2);
end